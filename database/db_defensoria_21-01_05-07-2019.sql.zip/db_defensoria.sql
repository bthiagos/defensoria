-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 05-Jul-2019 às 15:35
-- Versão do servidor: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_defensoria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `areadodireito`
--

CREATE TABLE `areadodireito` (
  `idareadodireito` int(11) NOT NULL,
  `tipodireito` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `areadodireito`
--

INSERT INTO `areadodireito` (`idareadodireito`, `tipodireito`) VALUES
(1, 'Civel'),
(2, 'Familia'),
(3, 'Consumidor'),
(4, 'Fazenda Publica'),
(5, 'Criminal');

-- --------------------------------------------------------

--
-- Estrutura da tabela `assistido`
--

CREATE TABLE `assistido` (
  `idassistido` int(11) NOT NULL,
  `nome_assistido` varchar(100) COLLATE utf8_bin NOT NULL,
  `sexo_assistido` varchar(20) COLLATE utf8_bin NOT NULL,
  `cpf_assistido` varchar(11) COLLATE utf8_bin NOT NULL,
  `estadocivil_assistido` varchar(50) COLLATE utf8_bin NOT NULL,
  `email_assistido` varchar(80) COLLATE utf8_bin NOT NULL,
  `data_cadastro` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `assistido`
--

INSERT INTO `assistido` (`idassistido`, `nome_assistido`, `sexo_assistido`, `cpf_assistido`, `estadocivil_assistido`, `email_assistido`, `data_cadastro`) VALUES
(1, 'Maria das Dores', 'feminino', '11111111111', 'Divorciado(a)', 'mariadasdores@maria.com', '2019-07-01 18:10:31');

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimento`
--

CREATE TABLE `atendimento` (
  `idatendimento` int(11) NOT NULL,
  `nome_assistido` varchar(100) COLLATE utf8_bin NOT NULL,
  `cpf_assistido` varchar(11) COLLATE utf8_bin NOT NULL,
  `sexo_assistido` varchar(45) COLLATE utf8_bin NOT NULL,
  `email_assistido` varchar(80) COLLATE utf8_bin NOT NULL,
  `estadocivil_assistido` varchar(45) COLLATE utf8_bin NOT NULL,
  `idareadodireito` int(11) NOT NULL,
  `idestagiario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `atendimento`
--

INSERT INTO `atendimento` (`idatendimento`, `nome_assistido`, `cpf_assistido`, `sexo_assistido`, `email_assistido`, `estadocivil_assistido`, `idareadodireito`, `idestagiario`) VALUES
(2, 'Carla da Silva Sauro', '2147483647', 'feminino', 'carlinhasauro@yahoo.com.br', 'Casado(a)', 0, 0),
(3, 'Mayara Mello', '2147483647', 'feminino', 'mayamello@gmail.com', 'casado(a)', 0, 2),
(4, 'Aleluia GlÃ³ria', '2147483647', 'masculino', 'aleluiagloria@gloria.com', 'Solteiro(a)', 1, 0),
(5, 'Vandro Augusto de Paula', '2147483647', 'masculino', 'vandroaugusto@vds.com', 'Viuvo(a)', 3, 0),
(6, 'Claudia Campos', '66666666666', 'feminino', 'claucla@campo.com', 'Divorciado(a)', 4, 0),
(7, 'Felipe Andre', '77171772727', 'masculino', 'felipeandre@gmail.com', 'Casado(a)', 2, 0),
(8, 'Roberto Carlos Zidane Beckham', '81818181818', 'masculino', 'robertocarloszidane@beckham.com', 'Casado(a)', 5, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_estagiario`
--

CREATE TABLE `tipo_estagiario` (
  `idtipoestagiario` int(11) NOT NULL,
  `cargo` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `tipo_estagiario`
--

INSERT INTO `tipo_estagiario` (`idtipoestagiario`, `cargo`) VALUES
(10, 'Estagiario Contratado'),
(20, 'Estagiario Voluntario');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `idestagiario` int(11) NOT NULL,
  `matricula` varchar(10) NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `email` varchar(80) NOT NULL,
  `senha` varchar(35) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `idtipoestagiario` int(11) NOT NULL,
  `hora_estagiario` varchar(50) NOT NULL,
  `instituicaoensino` varchar(100) NOT NULL,
  `data_cadastro` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`idestagiario`, `matricula`, `nome`, `email`, `senha`, `idtipoestagiario`, `hora_estagiario`, `instituicaoensino`, `data_cadastro`) VALUES
(1, '12345', 'Thiago Bastos', 'bthiagos@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 0, 'FULL_TIME', 'FAETERJ Rio', '2019-06-28 11:31:13'),
(2, '31313', 'Jamal Ramos', 'jamalramos@gmail.com', '1111', 10, '09-10', 'UFRJ', '2019-07-02 15:59:28'),
(3, '54321', 'Guilherme JosÃ©', 'guilhermejose@gmail.com', '01cfcd4f6b8770febfb40cb906715822', 10, 'ter_qui_13_19', 'FAETERJ Rio', '2019-07-03 12:00:01'),
(4, '55641', 'MagnÃ³lia Pereira', 'magmag@uol.com.br', '202cb962ac59075b964b07152d234b70', 20, 'ter_qui_13_19', 'UERJ', '2019-07-03 16:01:16'),
(5, '44422', 'Anderson', 'anderson@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 10, 'seg_a_sex_07_13', 'UFF', '2019-07-04 19:32:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `areadodireito`
--
ALTER TABLE `areadodireito`
  ADD PRIMARY KEY (`idareadodireito`);

--
-- Indexes for table `assistido`
--
ALTER TABLE `assistido`
  ADD PRIMARY KEY (`idassistido`);

--
-- Indexes for table `atendimento`
--
ALTER TABLE `atendimento`
  ADD UNIQUE KEY `idatendimento` (`idatendimento`),
  ADD KEY `idestagiario` (`idestagiario`);

--
-- Indexes for table `tipo_estagiario`
--
ALTER TABLE `tipo_estagiario`
  ADD PRIMARY KEY (`idtipoestagiario`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD UNIQUE KEY `idestagiario` (`idestagiario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `areadodireito`
--
ALTER TABLE `areadodireito`
  MODIFY `idareadodireito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `assistido`
--
ALTER TABLE `assistido`
  MODIFY `idassistido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `atendimento`
--
ALTER TABLE `atendimento`
  MODIFY `idatendimento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tipo_estagiario`
--
ALTER TABLE `tipo_estagiario`
  MODIFY `idtipoestagiario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idestagiario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
