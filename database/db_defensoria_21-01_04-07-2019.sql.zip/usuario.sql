-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 05-Jul-2019 às 02:00
-- Versão do servidor: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_defensoria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `idestagiario` int(11) NOT NULL,
  `matricula` varchar(10) NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `email` varchar(80) NOT NULL,
  `senha` varchar(35) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `idtipoestagiario` int(11) NOT NULL,
  `hora_estagiario` varchar(50) NOT NULL,
  `instituicaoensino` varchar(100) NOT NULL,
  `data_cadastro` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`idestagiario`, `matricula`, `nome`, `email`, `senha`, `idtipoestagiario`, `hora_estagiario`, `instituicaoensino`, `data_cadastro`) VALUES
(1, '12345', 'Thiago Bastos', 'bthiagos@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 0, 'FULL_TIME', 'FAETERJ Rio', '2019-06-28 11:31:13'),
(2, '31313', 'Jamal Ramos', 'jamalramos@gmail.com', '1111', 10, '09-10', 'UFRJ', '2019-07-02 15:59:28'),
(3, '54321', 'Guilherme JosÃ©', 'guilhermejose@gmail.com', '01cfcd4f6b8770febfb40cb906715822', 10, 'ter_qui_13_19', 'FAETERJ Rio', '2019-07-03 12:00:01'),
(4, '55641', 'MagnÃ³lia Pereira', 'magmag@uol.com.br', '202cb962ac59075b964b07152d234b70', 20, 'ter_qui_13_19', 'UERJ', '2019-07-03 16:01:16'),
(5, '44422', 'Anderson', 'anderson@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 10, 'seg_a_sex_07_13', 'UFF', '2019-07-04 19:32:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD UNIQUE KEY `idestagiario` (`idestagiario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idestagiario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
