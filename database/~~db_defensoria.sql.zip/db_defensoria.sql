-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01-Jul-2019 às 04:42
-- Versão do servidor: 10.3.16-MariaDB
-- versão do PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_defensoria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimento`
--

CREATE TABLE `atendimento` (
  `idatendimento` int(11) NOT NULL,
  `nome_assistido` varchar(100) COLLATE utf8_bin NOT NULL,
  `cpf_assistido` varchar(11) COLLATE utf8_bin NOT NULL,
  `sexo_assistido` varchar(45) COLLATE utf8_bin NOT NULL,
  `email_assistido` varchar(80) COLLATE utf8_bin NOT NULL,
  `estadocivil_assistido` varchar(45) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `atendimento`
--

INSERT INTO `atendimento` (`idatendimento`, `nome_assistido`, `cpf_assistido`, `sexo_assistido`, `email_assistido`, `estadocivil_assistido`) VALUES
(1, 'Maria das Dores', '2147483647', 'feminino', 'mariadasdores@maria.com', 'Solteiro(a)'),
(2, 'Carla da Silva Sauro', '2147483647', 'feminino', 'carlinhasauro@yahoo.com.br', 'Casado(a)'),
(3, 'JoÃ£o PÃ© de FeijÃ£o', '2147483647', 'masculino', 'joaopedefeijao@joaope.com', 'Divorciado(a)'),
(4, 'Paulo Melo', '2147483647', 'masculino', 'pppppaulo@gmail.com', 'Viuvo(a)'),
(5, 'Jorge Manuel da Silva', '12312312333', 'masculino', 'jorginhommmm@gmail.com', 'Viuvo(a)');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `idestagiario` int(11) NOT NULL,
  `matricula` varchar(10) COLLATE utf8_bin NOT NULL,
  `nome` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(80) COLLATE utf8_bin NOT NULL,
  `senha` varchar(35) COLLATE utf8_bin NOT NULL,
  `tipo_estagiario` varchar(50) COLLATE utf8_bin NOT NULL,
  `hora_estagiario` varchar(50) COLLATE utf8_bin NOT NULL,
  `data_cadastro` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`idestagiario`, `matricula`, `nome`, `email`, `senha`, `tipo_estagiario`, `hora_estagiario`, `data_cadastro`) VALUES
(1, '12345', 'Thiago Bastos', 'bthiagos@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Administrador', 'FULL_TIME', '2019-06-28 11:31:13'),
(2, '00002', 'Guilherme JosÃ©', 'guilhermejose@gmail.com', '202cb962ac59075b964b07152d234b70', 'est_contratado', 'seg_a_sex_13_19', '2019-06-30 23:29:16');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `atendimento`
--
ALTER TABLE `atendimento`
  ADD UNIQUE KEY `idatendimento` (`idatendimento`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD UNIQUE KEY `idestagiario` (`idestagiario`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `atendimento`
--
ALTER TABLE `atendimento`
  MODIFY `idatendimento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idestagiario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
