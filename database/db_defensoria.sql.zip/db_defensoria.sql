-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 03-Jul-2019 às 17:11
-- Versão do servidor: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_defensoria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `areadodireito`
--

CREATE TABLE `areadodireito` (
  `idareadodireito` int(11) NOT NULL,
  `tipodireito` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `areadodireito`
--

INSERT INTO `areadodireito` (`idareadodireito`, `tipodireito`) VALUES
(1, 'Civel'),
(2, 'Familia'),
(3, 'Consumidor'),
(4, 'Fazenda Publica'),
(5, 'Criminal');

-- --------------------------------------------------------

--
-- Estrutura da tabela `assistido`
--

CREATE TABLE `assistido` (
  `idassistido` int(11) NOT NULL,
  `nome_assistido` varchar(100) COLLATE utf8_bin NOT NULL,
  `sexo_assistido` varchar(20) COLLATE utf8_bin NOT NULL,
  `cpf_assistido` varchar(11) COLLATE utf8_bin NOT NULL,
  `estadocivil_assistido` varchar(50) COLLATE utf8_bin NOT NULL,
  `email_assistido` varchar(80) COLLATE utf8_bin NOT NULL,
  `data_cadastro` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `assistido`
--

INSERT INTO `assistido` (`idassistido`, `nome_assistido`, `sexo_assistido`, `cpf_assistido`, `estadocivil_assistido`, `email_assistido`, `data_cadastro`) VALUES
(1, 'Maria das Dores', 'feminino', '11111111111', 'Divorciado(a)', 'mariadasdores@maria.com', '2019-07-01 18:10:31');

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimento`
--

CREATE TABLE `atendimento` (
  `idatendimento` int(11) NOT NULL,
  `nome_assistido` varchar(100) COLLATE utf8_bin NOT NULL,
  `cpf_assistido` varchar(11) COLLATE utf8_bin NOT NULL,
  `sexo_assistido` varchar(45) COLLATE utf8_bin NOT NULL,
  `email_assistido` varchar(80) COLLATE utf8_bin NOT NULL,
  `estadocivil_assistido` varchar(45) COLLATE utf8_bin NOT NULL,
  `idareadodireito` int(11) NOT NULL,
  `idestagiario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `atendimento`
--

INSERT INTO `atendimento` (`idatendimento`, `nome_assistido`, `cpf_assistido`, `sexo_assistido`, `email_assistido`, `estadocivil_assistido`, `idareadodireito`, `idestagiario`) VALUES
(2, 'Carla da Silva Sauro', '2147483647', 'feminino', 'carlinhasauro@yahoo.com.br', 'Casado(a)', 0, 0),
(3, 'Mayara Mello', '2147483647', 'feminino', 'mayamello@gmail.com', 'casado(a)', 0, 2),
(4, 'Aleluia GlÃ³ria', '2147483647', 'masculino', 'aleluiagloria@gloria.com', 'Solteiro(a)', 1, 0),
(5, 'Vandro Augusto de Paula', '2147483647', 'masculino', 'vandroaugusto@vds.com', 'Viuvo(a)', 3, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_estagiario`
--

CREATE TABLE `tipo_estagiario` (
  `idtipoestagiario` int(11) NOT NULL,
  `cargo` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `tipo_estagiario`
--

INSERT INTO `tipo_estagiario` (`idtipoestagiario`, `cargo`) VALUES
(10, 'Estagiario Contratado'),
(20, 'Estagiario Voluntario');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `idestagiario` int(11) NOT NULL,
  `matricula` varchar(10) COLLATE utf8_bin NOT NULL,
  `nome` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(80) COLLATE utf8_bin NOT NULL,
  `senha` varchar(35) COLLATE utf8_bin NOT NULL,
  `idtipoestagiario` int(11) NOT NULL,
  `hora_estagiario` varchar(50) COLLATE utf8_bin NOT NULL,
  `data_cadastro` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`idestagiario`, `matricula`, `nome`, `email`, `senha`, `idtipoestagiario`, `hora_estagiario`, `data_cadastro`) VALUES
(1, '12345', 'Thiago Bastos', 'bthiagos@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 0, 'FULL_TIME', '2019-06-28 11:31:13'),
(2, '31313', 'Jamal Ramos', 'jamalramos@gmail.com', '1111', 10, '09-10', '2019-07-02 15:59:28'),
(3, '54321', 'Guilherme JosÃ©', 'guilhermejose@gmail.com', '01cfcd4f6b8770febfb40cb906715822', 10, 'ter_qui_13_19', '2019-07-03 12:00:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `areadodireito`
--
ALTER TABLE `areadodireito`
  ADD PRIMARY KEY (`idareadodireito`);

--
-- Indexes for table `assistido`
--
ALTER TABLE `assistido`
  ADD PRIMARY KEY (`idassistido`);

--
-- Indexes for table `atendimento`
--
ALTER TABLE `atendimento`
  ADD UNIQUE KEY `idatendimento` (`idatendimento`),
  ADD KEY `idestagiario` (`idestagiario`);

--
-- Indexes for table `tipo_estagiario`
--
ALTER TABLE `tipo_estagiario`
  ADD PRIMARY KEY (`idtipoestagiario`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD UNIQUE KEY `idestagiario` (`idestagiario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `areadodireito`
--
ALTER TABLE `areadodireito`
  MODIFY `idareadodireito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `assistido`
--
ALTER TABLE `assistido`
  MODIFY `idassistido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `atendimento`
--
ALTER TABLE `atendimento`
  MODIFY `idatendimento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tipo_estagiario`
--
ALTER TABLE `tipo_estagiario`
  MODIFY `idtipoestagiario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idestagiario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
