-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 17-Jul-2019 às 16:56
-- Versão do servidor: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_defensoria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `area_do_direito`
--

CREATE TABLE `area_do_direito` (
  `ID_DIREITO` int(30) NOT NULL,
  `NOME_DIREITO` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `area_do_direito`
--

INSERT INTO `area_do_direito` (`ID_DIREITO`, `NOME_DIREITO`) VALUES
(1, 'Civil'),
(2, 'Familia'),
(3, 'Consumidor'),
(4, 'Fazenda Publica'),
(5, 'Criminal');

-- --------------------------------------------------------

--
-- Estrutura da tabela `area_subdireito`
--

CREATE TABLE `area_subdireito` (
  `ID_SUBDIREITO` int(200) NOT NULL,
  `NOME_SUBDIREITO` varchar(300) NOT NULL,
  `ID_DIREITO` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `assistido`
--

CREATE TABLE `assistido` (
  `RG_ASS` int(9) NOT NULL,
  `NOME_ASS` varchar(100) NOT NULL,
  `EMAIL_ASS` varchar(80) NOT NULL,
  `TELEFONE_ASS` varchar(14) NOT NULL,
  `SEXO_ASS` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `assistido`
--

INSERT INTO `assistido` (`RG_ASS`, `NOME_ASS`, `EMAIL_ASS`, `TELEFONE_ASS`, `SEXO_ASS`) VALUES
(123456789, 'Paulo Mendes', 'paulomendes@uol.com.br', '(21)97002-7164', 'M'),
(312312312, 'Jesuita', 'fwrwer@hotmail.com', '(21)8888-3332', 'M'),
(963258741, 'Josefa de Almeida Lima', 'josefalmeida@lima.com', '(21)99235-8774', 'F');

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimento`
--

CREATE TABLE `atendimento` (
  `ID_ATENDIMENTO` int(225) NOT NULL,
  `MAT_FUNC` int(5) NOT NULL,
  `RG_ASS` int(9) NOT NULL,
  `ID_DIREITO` int(10) NOT NULL,
  `PRIORIDADE_ATENDIMENTO` varchar(10) NOT NULL,
  `COMENTARIO_ATENDIMENTO` varchar(5000) NOT NULL,
  `HORA_ATENDIMENTO` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `atendimento`
--

INSERT INTO `atendimento` (`ID_ATENDIMENTO`, `MAT_FUNC`, `RG_ASS`, `ID_DIREITO`, `PRIORIDADE_ATENDIMENTO`, `COMENTARIO_ATENDIMENTO`, `HORA_ATENDIMENTO`) VALUES
(1, 12345, 123456789, 3, 'Alta', 'O Sr Paulo Mendes afirmou que lesado pela empresa Light.', '2019-07-11 14:41:41'),
(2, 54321, 963258741, 5, 'Alta', 'A Sra Josefa foi agredida pelo seu ex-marido.', '2019-07-11 14:43:46'),
(3, 54321, 312312312, 3, 'MÃ©dia', 'tewwerqw', '2019-07-11 15:32:01'),
(4, 12345, 312312312, 4, 'Baixa', 'Testando mais de 1 atendimento com o mesmo assistido.', '2019-07-11 15:36:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `MAT_FUNC` int(5) NOT NULL,
  `ID_TIPO_FUNC` int(1) NOT NULL,
  `NOME_FUNC` varchar(100) NOT NULL,
  `SENHA_FUNC` varchar(50) NOT NULL,
  `HORA_EXPEDIENTE_FUNC` datetime NOT NULL,
  `INSTITUICAO_FUNC` varchar(40) NOT NULL,
  `DATA_CADASTRO_FUNC` datetime NOT NULL,
  `RG_FUNC` int(9) NOT NULL,
  `CPF_FUNC` varchar(11) NOT NULL,
  `EMAIL_FUNC` varchar(100) NOT NULL,
  `MATRICULA_INST_FUNC` varchar(10) NOT NULL,
  `ENDERECO_FUNC` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`MAT_FUNC`, `ID_TIPO_FUNC`, `NOME_FUNC`, `SENHA_FUNC`, `HORA_EXPEDIENTE_FUNC`, `INSTITUICAO_FUNC`, `DATA_CADASTRO_FUNC`, `RG_FUNC`, `CPF_FUNC`, `EMAIL_FUNC`, `MATRICULA_INST_FUNC`, `ENDERECO_FUNC`) VALUES
(12345, 1, 'Thiago Bastos', '827ccb0eea8a706c4c34a16891f84e7b', '0000-00-00 00:00:00', 'FAETERJ Rio', '2019-07-08 11:55:26', 129876543, '1213456789', 'bthiagos@gmail.com', '2147483647', 'Rua das Neves 127'),
(54321, 1, 'Guilherme Jose', '01cfcd4f6b8770febfb40cb906715822', '2019-07-10 19:00:00', '1212121212', '2019-07-11 14:35:40', 121212121, '11111111122', 'aaaa@dasda.com', '1212121212', '12121212');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_funcionario`
--

CREATE TABLE `tipo_funcionario` (
  `ID_TIPO_FUNC` int(1) NOT NULL,
  `CARGO_FUNC` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipo_funcionario`
--

INSERT INTO `tipo_funcionario` (`ID_TIPO_FUNC`, `CARGO_FUNC`) VALUES
(1, 'Administrador'),
(2, 'Estagiário Contratado'),
(3, 'Estagiário Voluntário');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area_do_direito`
--
ALTER TABLE `area_do_direito`
  ADD PRIMARY KEY (`ID_DIREITO`);

--
-- Indexes for table `assistido`
--
ALTER TABLE `assistido`
  ADD PRIMARY KEY (`RG_ASS`);

--
-- Indexes for table `atendimento`
--
ALTER TABLE `atendimento`
  ADD PRIMARY KEY (`ID_ATENDIMENTO`),
  ADD KEY `MAT_FUNC` (`MAT_FUNC`),
  ADD KEY `RG_ASS` (`RG_ASS`),
  ADD KEY `atendimento_ibfk_3` (`ID_DIREITO`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`MAT_FUNC`),
  ADD KEY `ID_TIPO_FUNC` (`ID_TIPO_FUNC`);

--
-- Indexes for table `tipo_funcionario`
--
ALTER TABLE `tipo_funcionario`
  ADD PRIMARY KEY (`ID_TIPO_FUNC`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `atendimento`
--
ALTER TABLE `atendimento`
  MODIFY `ID_ATENDIMENTO` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `atendimento`
--
ALTER TABLE `atendimento`
  ADD CONSTRAINT `atendimento_ibfk_1` FOREIGN KEY (`MAT_FUNC`) REFERENCES `funcionario` (`MAT_FUNC`),
  ADD CONSTRAINT `atendimento_ibfk_2` FOREIGN KEY (`RG_ASS`) REFERENCES `assistido` (`RG_ASS`),
  ADD CONSTRAINT `atendimento_ibfk_3` FOREIGN KEY (`ID_DIREITO`) REFERENCES `area_do_direito` (`ID_DIREITO`);

--
-- Limitadores para a tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD CONSTRAINT `funcionario_ibfk_1` FOREIGN KEY (`ID_TIPO_FUNC`) REFERENCES `tipo_funcionario` (`ID_TIPO_FUNC`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
